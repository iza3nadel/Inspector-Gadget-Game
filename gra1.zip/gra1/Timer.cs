﻿using System;
using System.Diagnostics;

namespace gra1
{
    public class Timer
    {
        private Stopwatch stopwatch;

        public Timer()
        {
            stopwatch = new Stopwatch();
        }

        public void Start()
        {
            stopwatch.Start();
        }

        public void Stop()
        {
            stopwatch.Stop();
        }

        public void Reset()
        {
            stopwatch.Reset();
        }

        public TimeSpan Elapsed => stopwatch.Elapsed;

        public void DisplayElapsed()
        {
            Console.WriteLine($"Czas gry: {stopwatch.Elapsed}");
        }
    }
}
