﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

//namespace gra1
//{
//    public abstract class Level
//    {
//        public abstract string Text { get; }
//        public abstract string SkipWord { get; }
//    }
//}
