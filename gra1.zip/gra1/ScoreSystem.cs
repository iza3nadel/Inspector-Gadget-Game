﻿namespace gra1
{
    public class ScoreSystem
    {
        private int score;

        public ScoreSystem()
        {
            score = 0;
        }

        public void AddPoints(int points)
        {
            score += points;
        }

        public int GetScore()
        {
            return score;
        }
    }
}
