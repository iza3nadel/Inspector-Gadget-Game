﻿using System.IO;

namespace gra1
{
    public abstract class Level
    {
        protected string introduction;
        protected string text;
        protected string skipWord;

        public Level(string introductionFile, string textFile, string skipWordFile)
        {
            LoadContent(introductionFile, textFile, skipWordFile);
        }

        private void LoadContent(string introductionFile, string textFile, string skipWordFile)
        {
            try
            {
                introduction = File.ReadAllText(introductionFile);
                text = File.ReadAllText(textFile);
                skipWord = File.ReadAllText(skipWordFile).Trim(); // Trim to remove any extra new lines or spaces
            }
            catch (Exception ex)
            {
                Console.WriteLine("Wystąpił błąd podczas wczytywania zawartości pliku: " + ex.Message);
            }
        }

        public string Introduction
        {
            get { return introduction; }
        }

        public string Text
        {
            get { return text; }
        }

        public string SkipWord
        {
            get { return skipWord; }
        }
    }

}
