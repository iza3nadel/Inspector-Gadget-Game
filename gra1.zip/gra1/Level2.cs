﻿using System.Reflection.Emit;

namespace gra1
{
    public class Level2 : Level
    {
        public Level2() : base(@"C:\Users\trzna\OneDrive\Pulpit\uni\c#\gra1\Introduction\Level2_Introduction.txt",
                               @"C:\Users\trzna\OneDrive\Pulpit\uni\c#\gra1\Text\Level2_Text.txt",
                               @"C:\Users\trzna\OneDrive\Pulpit\uni\c#\gra1\SkipWord\Level2_SkipWord.txt")
        {
        }
    }
}
