﻿using System;
using System.Collections.Generic;
using System.Linq;

namespace gra1
{
    public class Program
    {
        static void Main(string[] args)
        {
            Game game = new Game();
            game.Play();
        }
    }
}
