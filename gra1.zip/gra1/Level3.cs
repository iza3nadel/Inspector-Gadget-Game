﻿using System.Reflection.Emit;

namespace gra1
{
    public class Level3 : Level
    {
        public Level3() : base(@"C:\Users\trzna\OneDrive\Pulpit\uni\c#\gra1\Introduction\Level3_Introduction.txt",
                               @"C:\Users\trzna\OneDrive\Pulpit\uni\c#\gra1\Text\Level3_Text.txt",
                               @"C:\Users\trzna\OneDrive\Pulpit\uni\c#\gra1\SkipWord\Level3_SkipWord.txt")
        {
        }
    }
}
