﻿using System.Reflection.Emit;

namespace gra1
{
    public class Level5 : Level
    {
        public Level5() : base(@"C:\Users\trzna\OneDrive\Pulpit\uni\c#\gra1\Introduction\Level5_Introduction.txt",
                               @"C:\Users\trzna\OneDrive\Pulpit\uni\c#\gra1\Text\Level5_Text.txt",
                               @"C:\Users\trzna\OneDrive\Pulpit\uni\c#\gra1\SkipWord\Level5_SkipWord.txt")
        {
        }
    }
}
