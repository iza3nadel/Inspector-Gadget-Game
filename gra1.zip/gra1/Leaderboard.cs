﻿using System;
using System.Collections.Generic;
using System.Linq;

namespace gra1
{
    public class Leaderboard
    {
        private List<(string Name, int Score, TimeSpan Time)> scores;

        public Leaderboard()
        {
            scores = new List<(string Name, int Score, TimeSpan Time)>();
        }

        public void AddScore(string name, int score, TimeSpan time)
        {
            scores.Add((name, score, time));
        }

        public void DisplayTopScores(int top)
        {
            var topScores = scores.OrderByDescending(s => s.Score).ThenBy(s => s.Time).Take(top);
            Console.WriteLine("Najlepsze wyniki:");
            foreach (var score in topScores)
            {
                Console.WriteLine($"{score.Name} - {score.Score} punkty - {score.Time}");
            }
        }
    }
}
