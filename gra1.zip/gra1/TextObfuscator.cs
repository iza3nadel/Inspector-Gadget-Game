﻿namespace gra1
{
    public class TextObfuscator
    {
        private string originalText;
        private string text;
        private List<char> hiddenLetters;
        private string skipWord;
        private int lettersToMask;

        public TextObfuscator(string text, string skipWord, int lettersToMask)
        {
            originalText = text;
            this.text = text;
            this.skipWord = skipWord;
            this.lettersToMask = lettersToMask;
            hiddenLetters = new List<char>();
        }

        private void Obfuscate()
        {
            var letters = new HashSet<char>(originalText.Where(char.IsLetter).Select(char.ToLower));
            var random = new Random();
            hiddenLetters = letters.OrderBy(x => random.Next()).Take(lettersToMask).ToList(); // Użycie lettersToMask

            foreach (var letter in hiddenLetters)
            {
                text = text.Replace(letter.ToString(), "_").Replace(char.ToUpper(letter).ToString(), "_");
            }
        }

        public bool PlayLevel(int maxAttempts)
        {
            Obfuscate();
            int attempts = 0;
            var guessedLetters = new HashSet<char>();

            while (text.Contains('_') && attempts < maxAttempts)
            {
                Console.WriteLine(text);
                Console.Write("Zgadnij literę lub wpisz hasło, aby przejść do następnego poziomu: ");
                var guess = Console.ReadLine().ToLower();
                Console.WriteLine("\n");

                if (guess == skipWord.ToLower())
                {
                    return true;
                }

                if (guess.Length == 1 && hiddenLetters.Contains(guess[0]))
                {
                    guessedLetters.Add(guess[0]);
                    text = new string(originalText.Select(c => guessedLetters.Contains(char.ToLower(c)) ? c : (hiddenLetters.Contains(char.ToLower(c)) ? '_' : c)).ToArray());
                }
                else
                {
                    attempts++;
                    Console.WriteLine($"Niepoprawna litera! Pozostałe próby: {maxAttempts - attempts}");
                }
            }

            return !text.Contains('_');
        }
    }
}