﻿using System.Reflection.Emit;

namespace gra1
{
    public class Level4 : Level
    {
        public Level4() : base(@"C:\Users\trzna\OneDrive\Pulpit\uni\c#\gra1\Introduction\Level4_Introduction.txt",
                               @"C:\Users\trzna\OneDrive\Pulpit\uni\c#\gra1\Text\Level4_Text.txt",
                               @"C:\Users\trzna\OneDrive\Pulpit\uni\c#\gra1\SkipWord\Level4_SkipWord.txt")
        { 
        }
    }
}
