﻿using System;
using System.Collections.Generic;
using System.IO;

namespace gra1
{
    public class Game
    {
        private List<Level> levels;
        private Player player;
        private ScoreSystem scoreSystem;
        private Leaderboard leaderboard;
        private Timer timer; // Dodanie pola timer

        private const int maxAttempts = 3;
        private const int initialLettersToMask = 5; // Liczba liter do zamaskowania na początku

        public Game()
        {
            levels = new List<Level> { new Level1(), new Level2(), new Level3(), new Level4(), new Level5() };
            leaderboard = new Leaderboard(); // Inicjalizacja tabeli wyników
            timer = new Timer(); // Inicjalizacja timera
        }

        private void ShowInstructions()
        {
            Console.Clear();
            string instructions = File.ReadAllText(@"C:\Users\trzna\OneDrive\Pulpit\uni\c#\gra1\Instructions\Instructions.txt");
            Console.WriteLine($"Witaj, {player.Name}!");
            Console.WriteLine(instructions);
            Console.ReadKey();
            Console.Clear();
        }

        public void Play()
        {
            do
            {
                Console.Write("Podaj swoje imię: ");
                player = new Player(Console.ReadLine());
                scoreSystem = new ScoreSystem();

                ShowInstructions();
                timer.Reset(); // Resetowanie timera przed rozpoczęciem gry
                timer.Start(); // Uruchomienie timera na początku gry

                int lettersToMask = initialLettersToMask; // Ustawienie początkowej liczby liter do zamaskowania

                foreach (var level in levels)
                {
                    var textProperty = level.GetType().GetProperty("Text");
                    var skipWordProperty = level.GetType().GetProperty("SkipWord");
                    var introductionProperty = level.GetType().GetProperty("Introduction");

                    if (textProperty == null || skipWordProperty == null || introductionProperty == null)
                    {
                        Console.WriteLine("Błąd: Nie można znaleźć właściwości Text, SkipWord lub Introduction.");
                        return;
                    }

                    string introduction = (string)introductionProperty.GetValue(level);
                    string text = (string)textProperty.GetValue(level);
                    string skipWord = (string)skipWordProperty.GetValue(level);

                    Console.WriteLine($"\n{introduction}");
                    TextObfuscator obfuscator = new TextObfuscator(text, skipWord, lettersToMask);
                    if (!obfuscator.PlayLevel(maxAttempts))
                    {
                        Console.WriteLine($"Przegrana!");
                        timer.Stop(); // Zatrzymanie timera po zakończeniu gry
                        leaderboard.AddScore(player.Name, scoreSystem.GetScore(), timer.Elapsed); // Dodanie wyniku i czasu do tabeli wyników
                        leaderboard.DisplayTopScores(5); // Wyświetlenie najlepszych wyników
                        break;
                    }

                    // Dodawanie punktów po zakończeniu poziomu
                    scoreSystem.AddPoints(10); // Przykładowe dodanie punktów za ukończenie poziomu

                    // Zwiększenie liczby liter do zamaskowania na następnym poziomie
                    lettersToMask++;

                    Console.Clear();
                }

                timer.Stop(); // Zatrzymanie timera po zakończeniu gry
                leaderboard.AddScore(player.Name, scoreSystem.GetScore(), timer.Elapsed); // Dodanie wyniku i czasu do tabeli wyników
                Console.WriteLine($"Gratulacje, {player.Name}! Twój wynik to: {scoreSystem.GetScore()}");
                timer.DisplayElapsed(); // Wyświetlenie czasu gry
                leaderboard.DisplayTopScores(5); // Wyświetlenie najlepszych wyników

                string response;
                do
                {
                    Console.WriteLine("Czy nowy gracz chce zagrać? (tak/nie): ");
                    response = Console.ReadLine().ToLower();
                    if (response != "tak" && response != "nie")
                    {
                        Console.WriteLine("Proszę odpowiedzieć 'tak' lub 'nie'.");
                    }
                } while (response != "tak" && response != "nie");

            } while (Console.ReadLine().ToLower() == "tak");
        }
    }
}
