﻿using System.Reflection.Emit;

namespace gra1
{
    public class Level1 : Level
    {
        public Level1() : base(@"C:\Users\trzna\OneDrive\Pulpit\uni\c#\gra1\Introduction\Level1_Introduction.txt",
                               @"C:\Users\trzna\OneDrive\Pulpit\uni\c#\gra1\Text\Level1_Text.txt",
                               @"C:\Users\trzna\OneDrive\Pulpit\uni\c#\gra1\SkipWord\Level1_SkipWord.txt")
        {
        }
    }
}
